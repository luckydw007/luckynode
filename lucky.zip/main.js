const path = require('path');
const express = require('express');

const app = express();

app.use("/", express.static(path.join(__dirname, "public")));
app.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader(
        "Acess-Control-Allow-Header",
        "Origin, X-Requested-width, Content-Type, Accept"
    );
    res.setHeader(
        "Acess-Control-Allow-Methods",
        "GET, POST, PATCH, DELETE, OPTIONS"
    );
    next();
});

app.use('/drawResult',(req, res, next) => {
    res.send({"result": "5"});
});

app.use((req, res, next) => {
    res.sendFile(path.join(__dirname, "public","index.html"));
});

module.exports = app;